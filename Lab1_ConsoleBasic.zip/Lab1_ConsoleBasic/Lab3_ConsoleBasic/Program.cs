﻿using System;

namespace Bai3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Rằm Tháng Giêng");
            Console.WriteLine();
            Console.WriteLine("Rằm xuân lồng lộng trăng soi,");
            Console.WriteLine("Sông xuân nước lẫn màu trời thêm xuân.");
            Console.WriteLine("Giữa dòng bàn bạc việc quân,");
            Console.WriteLine("Khuya về bát ngát trăng ngân đầy thuyền.");
            Console.WriteLine();
            Console.WriteLine("Hồ Chí Minh");

            Console.ReadLine();
        }
    }
}