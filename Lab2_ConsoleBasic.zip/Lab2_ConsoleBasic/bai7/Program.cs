﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        if (n == 0)
        {
            Console.WriteLine("So chu so = 1");
        }
        else
        {
            int dem = 0;

            while (n != 0)
            {
                dem++;
                n /= 10;
            }

            Console.WriteLine("So chu so = " + dem);
        }

        Console.ReadKey();
    }
}