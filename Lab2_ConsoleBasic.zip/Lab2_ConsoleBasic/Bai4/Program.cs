﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap canh a: ");
        double a = double.Parse(Console.ReadLine());

        Console.Write("Nhap canh b: ");
        double b = double.Parse(Console.ReadLine());

        Console.Write("Nhap canh c: ");
        double c = double.Parse(Console.ReadLine());

        if (a + b > c && a + c > b && b + c > a)
        {
            Console.WriteLine("Day la mot tam giac.");

            if (a == b && b == c)
                Console.WriteLine("Tam giac deu.");
            else if (a == b || a == c || b == c)
                Console.WriteLine("Tam giac can.");
            else if (a * a + b * b == c * c ||
                     a * a + c * c == b * b ||
                     b * b + c * c == a * a)
                Console.WriteLine("Tam giac vuong.");
            else
                Console.WriteLine("Tam giac thuong.");

            double chuVi = a + b + c;

            double p = chuVi / 2;
            double dienTich = Math.Sqrt(
                p * (p - a) * (p - b) * (p - c)
            );

            Console.WriteLine("Chu vi = " + chuVi);
            Console.WriteLine("Dien tich = " + dienTich);
        }
        else
        {
            Console.WriteLine("Ba so vua nhap khong phai la ba canh cua tam giac.");
        }

        Console.ReadKey();
    }
}