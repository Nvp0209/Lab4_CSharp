﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        int tong = 0;

        while (n > 0)
        {
            tong += n % 10;
            n /= 10;
        }

        Console.WriteLine("Tong cac chu so = " + tong);

        Console.ReadKey();
    }
}