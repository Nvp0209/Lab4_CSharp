﻿using System;

namespace Lab3
{
    class PhanSo
    {
        public int TuSo { get; set; }
        public int MauSo { get; set; }

        public PhanSo()
        {
            TuSo = 0;
            MauSo = 1;
        }

        public PhanSo(int tuSo, int mauSo)
        {
            if (mauSo == 0)
                throw new Exception("Mau so khong duoc bang 0.");

            TuSo = tuSo;
            MauSo = mauSo;

            RutGon();
        }

        private int UCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);

            while (b != 0)
            {
                int temp = a % b;
                a = b;
                b = temp;
            }

            return a;
        }

        public void RutGon()
        {
            int ucln = UCLN(TuSo, MauSo);

            TuSo /= ucln;
            MauSo /= ucln;

            if (MauSo < 0)
            {
                TuSo = -TuSo;
                MauSo = -MauSo;
            }
        }

        public PhanSo Cong(PhanSo b)
        {
            int tu = TuSo * b.MauSo + b.TuSo * MauSo;
            int mau = MauSo * b.MauSo;

            return new PhanSo(tu, mau);
        }

        public PhanSo Tru(PhanSo b)
        {
            int tu = TuSo * b.MauSo - b.TuSo * MauSo;
            int mau = MauSo * b.MauSo;

            return new PhanSo(tu, mau);
        }

        public PhanSo Nhan(PhanSo b)
        {
            return new PhanSo(TuSo * b.TuSo, MauSo * b.MauSo);
        }

        public PhanSo Chia(PhanSo b)
        {
            if (b.TuSo == 0)
                throw new Exception("Khong the chia cho phan so co tu so bang 0.");

            return new PhanSo(TuSo * b.MauSo, MauSo * b.TuSo);
        }

        public void HienThi()
        {
            Console.WriteLine(TuSo + "/" + MauSo);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap phan so thu nhat:");
            Console.Write("Tu so: ");
            int tu1 = int.Parse(Console.ReadLine());

            Console.Write("Mau so: ");
            int mau1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Nhap phan so thu hai:");
            Console.Write("Tu so: ");
            int tu2 = int.Parse(Console.ReadLine());

            Console.Write("Mau so: ");
            int mau2 = int.Parse(Console.ReadLine());

            try
            {
                PhanSo ps1 = new PhanSo(tu1, mau1);
                PhanSo ps2 = new PhanSo(tu2, mau2);

                Console.Write("Phan so 1: ");
                ps1.HienThi();

                Console.Write("Phan so 2: ");
                ps2.HienThi();

                Console.Write("Tong: ");
                ps1.Cong(ps2).HienThi();

                Console.Write("Hieu: ");
                ps1.Tru(ps2).HienThi();

                Console.Write("Tich: ");
                ps1.Nhan(ps2).HienThi();

                Console.Write("Thuong: ");
                ps1.Chia(ps2).HienThi();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Loi: " + ex.Message);
            }

            Console.ReadKey();
        }
    }
}