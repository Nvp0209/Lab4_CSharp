﻿namespace Lap5
{
    public class HangHoa
    {
        public string MaHang { get; set; }
        public string TenHang { get; set; }
        public double DonGia { get; set; }

        public HangHoa()
        {

        }

        public HangHoa(string maHang, string tenHang, double donGia)
        {
            MaHang = maHang;
            TenHang = tenHang;
            DonGia = donGia >= 0 ? donGia : 0;
        }

        public static bool operator >(HangHoa a, HangHoa b)
        {
            return a.DonGia > b.DonGia;
        }

        public static bool operator <(HangHoa a, HangHoa b)
        {
            return a.DonGia < b.DonGia;
        }

        public override string ToString()
        {
            return $"{MaHang,-10} | {TenHang,-25} | {DonGia,12:N0}";
        }
    }
}