﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        int f1 = 0;
        int f2 = 1;
        int tong = 0;

        Console.Write("Day Fibonacci: ");

        for (int i = 1; i <= n; i++)
        {
            Console.Write(f1 + " ");

            tong += f1;

            int f3 = f1 + f2;
            f1 = f2;
            f2 = f3;
        }

        Console.WriteLine("\nTong = " + tong);

        Console.ReadKey();
    }
}