﻿using System;

namespace Bai2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Xin chao .NET");
            Console.WriteLine("Xin chao ngon ngu lap trinh C#");
            Console.WriteLine("Day la chuong trinh Console dau tien cua toi");

            Console.WriteLine();
            Console.WriteLine("Nguyen Viet Phuc");
            Console.WriteLine("20230204");
            Console.WriteLine("Ngay thuc hanh: 18-06-2026");

            Console.ReadLine();
        }
    }
}