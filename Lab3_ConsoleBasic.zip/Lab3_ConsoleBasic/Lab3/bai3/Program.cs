﻿using System;

namespace Lab3
{
    class SinhVien
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public string Lop { get; set; }
        public double DiemToan { get; set; }
        public double DiemLy { get; set; }
        public double DiemTin { get; set; }

        public SinhVien()
        {
        }

        public SinhVien(string maSV, string hoTen, string lop,
                         double diemToan, double diemLy, double diemTin)
        {
            MaSV = maSV;
            HoTen = hoTen;
            Lop = lop;
            DiemToan = diemToan;
            DiemLy = diemLy;
            DiemTin = diemTin;
        }

        public double TinhDiemTrungBinh()
        {
            return (DiemToan + DiemLy + DiemTin) / 3;
        }

        public string XepLoai()
        {
            double dtb = TinhDiemTrungBinh();

            if (dtb >= 8.5)
                return "Gioi";
            if (dtb >= 7.0)
                return "Kha";
            if (dtb >= 5.0)
                return "Trung binh";

            return "Yeu";
        }

        public void HienThiThongTin()
        {
            Console.WriteLine("{0,-10} {1,-25} {2,-12} {3,8:F2} {4,12}",
                MaSV, HoTen, Lop, TinhDiemTrungBinh(), XepLoai());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap ma sinh vien: ");
            string maSV = Console.ReadLine();

            Console.Write("Nhap ho ten: ");
            string hoTen = Console.ReadLine();

            Console.Write("Nhap lop: ");
            string lop = Console.ReadLine();

            Console.Write("Nhap diem Toan: ");
            double toan = double.Parse(Console.ReadLine());

            Console.Write("Nhap diem Ly: ");
            double ly = double.Parse(Console.ReadLine());

            Console.Write("Nhap diem Tin: ");
            double tin = double.Parse(Console.ReadLine());

            SinhVien sv = new SinhVien(maSV, hoTen, lop, toan, ly, tin);

            Console.WriteLine("\nDANH SACH SINH VIEN");
            Console.WriteLine("{0,-10} {1,-25} {2,-12} {3,8} {4,12}",
                "Ma SV", "Ho ten", "Lop", "DTB", "Xep loai");

            sv.HienThiThongTin();

            Console.ReadKey();
        }
    }
}