﻿namespace Lap5
{
    public class KhachHang
    {
        public string MaKhach { get; set; }
        public string TenKhach { get; set; }
        public string DiaChi { get; set; }

        public KhachHang()
        {

        }

        public KhachHang(string maKhach, string tenKhach, string diaChi)
        {
            MaKhach = maKhach;
            TenKhach = tenKhach;
            DiaChi = diaChi;
        }

        public override string ToString()
        {
            return $"{MaKhach} - {TenKhach} - {DiaChi}";
        }
    }
}