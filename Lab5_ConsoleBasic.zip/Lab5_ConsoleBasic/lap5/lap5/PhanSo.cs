﻿using System;

namespace Lap5
{
    public class PhanSo
    {
        public int TuSo { get; set; }
        public int MauSo { get; set; }

        public PhanSo()
        {
            TuSo = 0;
            MauSo = 1;
        }

        public PhanSo(int tuSo, int mauSo)
        {
            if (mauSo == 0)
                throw new ArgumentException("Mẫu số không được bằng 0");

            TuSo = tuSo;
            MauSo = mauSo;
            RutGon();
        }

        private int UCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);

            while (b != 0)
            {
                int temp = a % b;
                a = b;
                b = temp;
            }

            return a == 0 ? 1 : a;
        }

        public void RutGon()
        {
            int ucln = UCLN(TuSo, MauSo);

            TuSo /= ucln;
            MauSo /= ucln;

            if (MauSo < 0)
            {
                TuSo = -TuSo;
                MauSo = -MauSo;
            }
        }

        public static PhanSo operator +(PhanSo a, PhanSo b)
        {
            return new PhanSo(
                a.TuSo * b.MauSo + b.TuSo * a.MauSo,
                a.MauSo * b.MauSo);
        }

        public static PhanSo operator -(PhanSo a, PhanSo b)
        {
            return new PhanSo(
                a.TuSo * b.MauSo - b.TuSo * a.MauSo,
                a.MauSo * b.MauSo);
        }

        public static PhanSo operator *(PhanSo a, PhanSo b)
        {
            return new PhanSo(
                a.TuSo * b.TuSo,
                a.MauSo * b.MauSo);
        }

        public static PhanSo operator /(PhanSo a, PhanSo b)
        {
            if (b.TuSo == 0)
                throw new DivideByZeroException();

            return new PhanSo(
                a.TuSo * b.MauSo,
                a.MauSo * b.TuSo);
        }

        public override string ToString()
        {
            if (MauSo == 1)
                return TuSo.ToString();

            return $"{TuSo}/{MauSo}";
        }
    }
}