﻿using System;

namespace Lab3
{
    class NhanVien
    {
        public string MaNV { get; set; }
        public string HoTen { get; set; }
        public string ChucVu { get; set; }
        public double LuongCoBan { get; set; }
        public double HeSoLuong { get; set; }

        public NhanVien()
        {
        }

        public NhanVien(string maNV, string hoTen, string chucVu,
                         double luongCoBan, double heSoLuong)
        {
            MaNV = maNV;
            HoTen = hoTen;
            ChucVu = chucVu;
            LuongCoBan = luongCoBan;
            HeSoLuong = heSoLuong;
        }

        public double TinhLuong()
        {
            return LuongCoBan * HeSoLuong;
        }

        public double TinhPhuCap()
        {
            if (ChucVu.ToLower() == "truong phong")
                return 2000000;

            if (ChucVu.ToLower() == "pho phong")
                return 1000000;

            return 500000;
        }

        public double TinhTongThuNhap()
        {
            return TinhLuong() + TinhPhuCap();
        }

        public void HienThiThongTin()
        {
            Console.WriteLine("\nTHONG TIN NHAN VIEN");
            Console.WriteLine("Ma NV: " + MaNV);
            Console.WriteLine("Ho ten: " + HoTen);
            Console.WriteLine("Chuc vu: " + ChucVu);
            Console.WriteLine("Luong co ban: " + LuongCoBan);
            Console.WriteLine("He so luong: " + HeSoLuong);
            Console.WriteLine("Luong: " + TinhLuong());
            Console.WriteLine("Phu cap: " + TinhPhuCap());
            Console.WriteLine("Tong thu nhap: " + TinhTongThuNhap());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap ma nhan vien: ");
            string maNV = Console.ReadLine();

            Console.Write("Nhap ho ten: ");
            string hoTen = Console.ReadLine();

            Console.Write("Nhap chuc vu: ");
            string chucVu = Console.ReadLine();

            Console.Write("Nhap luong co ban: ");
            double luongCoBan = double.Parse(Console.ReadLine());

            Console.Write("Nhap he so luong: ");
            double heSoLuong = double.Parse(Console.ReadLine());

            NhanVien nv = new NhanVien(
                maNV,
                hoTen,
                chucVu,
                luongCoBan,
                heSoLuong
            );

            nv.HienThiThongTin();

            Console.ReadKey();
        }
    }
}