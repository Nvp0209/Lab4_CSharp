﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        int tong = 0;

        Console.Write("Cac so thoa man: ");

        for (int i = 1; i <= n; i++)
        {
            if (i % 3 == 0 || i % 5 == 0)
            {
                Console.Write(i + " ");
                tong += i;
            }
        }

        Console.WriteLine("\nTong = " + tong);

        Console.ReadKey();
    }
}