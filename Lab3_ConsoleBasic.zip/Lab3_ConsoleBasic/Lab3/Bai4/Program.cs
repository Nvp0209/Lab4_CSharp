﻿using System;

namespace Lab3
{
    class Diem
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Diem()
        {
            X = 0;
            Y = 0;
        }

        public Diem(double x, double y)
        {
            X = x;
            Y = y;
        }

        public double TinhKhoangCach(Diem d)
        {
            return Math.Sqrt(Math.Pow(d.X - X, 2) +
                             Math.Pow(d.Y - Y, 2));
        }

        public void HienThi()
        {
            Console.WriteLine("({0}, {1})", X, Y);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap diem thu nhat:");

            Console.Write("x1 = ");
            double x1 = double.Parse(Console.ReadLine());

            Console.Write("y1 = ");
            double y1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Nhap diem thu hai:");

            Console.Write("x2 = ");
            double x2 = double.Parse(Console.ReadLine());

            Console.Write("y2 = ");
            double y2 = double.Parse(Console.ReadLine());

            Diem d1 = new Diem(x1, y1);
            Diem d2 = new Diem(x2, y2);

            Console.Write("Diem thu nhat: ");
            d1.HienThi();

            Console.Write("Diem thu hai: ");
            d2.HienThi();

            Console.WriteLine("Khoang cach giua hai diem: "
                              + d1.TinhKhoangCach(d2));

            Console.ReadKey();
        }
    }
}