﻿using System;

class Program
{
    static bool LaNguyenTo(int n)
    {
        if (n < 2) return false;

        for (int i = 2; i <= Math.Sqrt(n); i++)
        {
            if (n % i == 0)
                return false;
        }

        return true;
    }

    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        int dem = 0;

        Console.WriteLine("Cac so nguyen to:");

        for (int i = 2; i <= n; i++)
        {
            if (LaNguyenTo(i))
            {
                Console.Write(i + " ");
                dem++;
            }
        }

        Console.WriteLine("\nSo luong = " + dem);

        Console.ReadKey();
    }
}