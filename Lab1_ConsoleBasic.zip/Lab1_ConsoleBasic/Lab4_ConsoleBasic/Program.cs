﻿using System;

namespace Bai4
{
    class Program
    {
        static void Main(string[] args)
        {
            const double PI = 3.14159;

            Console.Write("Nhap ban kinh r = ");
            double r = double.Parse(Console.ReadLine());

            if (r <= 0)
            {
                Console.WriteLine("Ban kinh khong hop le!");
            }
            else
            {
                double chuVi = 2 * PI * r;
                double dienTich = PI * r * r;

                Console.WriteLine("Chu vi hinh tron = " + chuVi);
                Console.WriteLine("Dien tich hinh tron = " + dienTich);
            }

            Console.ReadLine();
        }
    }
}