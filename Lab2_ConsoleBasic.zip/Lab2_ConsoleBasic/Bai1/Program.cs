﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        double s = 0;

        for (int i = 1; i <= n; i++)
        {
            s += 1.0 / i;
        }

        Console.WriteLine("Tong S = {0:F2}", s);

        Console.ReadKey();
    }
}
