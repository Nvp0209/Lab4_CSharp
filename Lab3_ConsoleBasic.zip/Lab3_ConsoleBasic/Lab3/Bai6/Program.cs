﻿using System;

namespace Lab3
{
    class HinhTron
    {
        public double BanKinh { get; set; }

        public HinhTron()
        {
            BanKinh = 1;
        }

        public HinhTron(double banKinh)
        {
            BanKinh = banKinh;
        }

        public double TinhChuVi()
        {
            return 2 * Math.PI * BanKinh;
        }

        public double TinhDienTich()
        {
            return Math.PI * BanKinh * BanKinh;
        }

        public void HienThiThongTin()
        {
            Console.WriteLine("Ban kinh: " + BanKinh);
            Console.WriteLine("Chu vi: " + TinhChuVi());
            Console.WriteLine("Dien tich: " + TinhDienTich());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap ban kinh: ");
            double r = double.Parse(Console.ReadLine());

            if (r <= 0)
            {
                Console.WriteLine("Ban kinh phai lon hon 0!");
            }
            else
            {
                HinhTron ht = new HinhTron(r);

                Console.WriteLine("\nTHONG TIN HINH TRON");
                ht.HienThiThongTin();
            }

            Console.ReadKey();
        }
    }
}