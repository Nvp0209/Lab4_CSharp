﻿using System;

namespace Lab3
{
    class TaiKhoanNganHang
    {
        public string SoTaiKhoan { get; set; }
        public string ChuTaiKhoan { get; set; }
        public double SoDu { get; set; }

        public TaiKhoanNganHang()
        {
        }

        public TaiKhoanNganHang(string soTaiKhoan, string chuTaiKhoan, double soDu)
        {
            SoTaiKhoan = soTaiKhoan;
            ChuTaiKhoan = chuTaiKhoan;
            SoDu = soDu;
        }

        public void NapTien(double soTien)
        {
            if (soTien > 0)
            {
                SoDu += soTien;
                Console.WriteLine("Nap tien thanh cong!");
            }
            else
            {
                Console.WriteLine("So tien nap phai lon hon 0.");
            }
        }

        public void RutTien(double soTien)
        {
            if (soTien <= 0)
            {
                Console.WriteLine("So tien rut phai lon hon 0.");
            }
            else if (soTien > SoDu)
            {
                Console.WriteLine("So du khong du.");
            }
            else
            {
                SoDu -= soTien;
                Console.WriteLine("Rut tien thanh cong!");
            }
        }

        public void ChuyenTien(TaiKhoanNganHang taiKhoanNhan, double soTien)
        {
            if (soTien <= 0)
            {
                Console.WriteLine("So tien chuyen phai lon hon 0.");
            }
            else if (soTien > SoDu)
            {
                Console.WriteLine("So du khong du de chuyen.");
            }
            else
            {
                SoDu -= soTien;
                taiKhoanNhan.SoDu += soTien;
                Console.WriteLine("Chuyen tien thanh cong!");
            }
        }

        public void HienThiSoDu()
        {
            Console.WriteLine("So du cua " + ChuTaiKhoan + ": " + SoDu);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            TaiKhoanNganHang tk1 =
                new TaiKhoanNganHang("001", "Nguyen Van A", 5000000);

            TaiKhoanNganHang tk2 =
                new TaiKhoanNganHang("002", "Tran Van B", 2000000);

            Console.WriteLine("SO DU BAN DAU");
            tk1.HienThiSoDu();
            tk2.HienThiSoDu();

            Console.WriteLine("\nNAP 1.000.000 VAO TK1");
            tk1.NapTien(1000000);
            tk1.HienThiSoDu();

            Console.WriteLine("\nRUT 500.000 TU TK1");
            tk1.RutTien(500000);
            tk1.HienThiSoDu();

            Console.WriteLine("\nCHUYEN 2.000.000 TU TK1 SANG TK2");
            tk1.ChuyenTien(tk2, 2000000);

            Console.WriteLine("\nSO DU SAU KHI CHUYEN");
            tk1.HienThiSoDu();
            tk2.HienThiSoDu();

            Console.ReadKey();
        }
    }
}