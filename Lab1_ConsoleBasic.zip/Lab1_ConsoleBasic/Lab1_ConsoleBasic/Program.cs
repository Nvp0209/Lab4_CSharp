﻿using System;

namespace Bai1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("TRUONG DAI HOC CONG NGHE DONG A");
            Console.WriteLine("KHOA CONG NGHE THONG TIN");
            Console.WriteLine("MON HOC: LAP TRINH .NET");
            Console.WriteLine("LAB 1: TONG QUAN .NET VA C# CONSOLE");

            Console.WriteLine("Ho ten sinh vien: Nguyen VIET Phuc");
            Console.WriteLine("Ma sinh vien: 20230204");
            Console.WriteLine("Lop: DCCNTT.14.C.1");

            Console.ReadLine();
        }
    }
}