﻿using Lap5;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lap5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            PhanSo p1 = new PhanSo(2, 4);
            PhanSo p2 = new PhanSo(5, 10);

            Console.WriteLine($"{p1} + {p2} = {p1 + p2}");
            Console.WriteLine($"{p1} - {p2} = {p1 - p2}");
            Console.WriteLine($"{p1} * {p2} = {p1 * p2}");
            Console.WriteLine($"{p1} / {p2} = {p1 / p2}");

            Console.WriteLine();

            SoNguyen s1 = new SoNguyen(2);
            SoNguyen s2 = new SoNguyen(9);

            Console.WriteLine($"{s1} + {s2} = {s1 + s2}");
            Console.WriteLine($"{s1} có phải số nguyên tố không? {s1.LaNguyenTo()}");

            Console.WriteLine();

            List<HangHoa> dsHang = new List<HangHoa>()
            {
                new HangHoa("H01","Bàn phím",250000),
                new HangHoa("H02","Chuột máy tính",150000),
                new HangHoa("H03","Màn hình",2500000),
                new HangHoa("H04","USB 32GB",120000),
                new HangHoa("H05","Ổ cứng SSD",1350000)
            };

            KhachHang khach =
                new KhachHang("KH01", "Nguyễn Viết Phúc", "Hà Nội");

            HoaDon hoaDon =
                new HoaDon("HD01", khach);

            hoaDon.ThemHang(dsHang[0], 2);
            hoaDon.ThemHang(dsHang[2], 1);
            hoaDon.ThemHang(dsHang[4], 1);

            hoaDon.InHoaDon();

            Console.WriteLine();

            HangHoa hangMax =
                dsHang.OrderByDescending(x => x.DonGia).First();

            Console.WriteLine("HÀNG HÓA CÓ ĐƠN GIÁ CAO NHẤT");
            Console.WriteLine(hangMax);

            Console.ReadKey();
        }
    }
}