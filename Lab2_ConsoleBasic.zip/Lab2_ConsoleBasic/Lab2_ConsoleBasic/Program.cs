﻿using System;

class Program
{
    static void Main()
    {
        int n;

        do
        {
            Console.Write("Nhap n (>0): ");
            n = int.Parse(Console.ReadLine());
        }
        while (n <= 0);

        int s = 0;

        for (int i = 2; i <= n; i += 2)
        {
            s += i;
        }

        Console.WriteLine("Tong = " + s);
        Console.ReadKey();
    }
}