﻿using System;

namespace Bai5
{
    class Program
    {
        static void Main(string[] args)
        {
            const double PI = 3.14159;

            Console.Write("Nhap ban kinh r = ");
            double r = double.Parse(Console.ReadLine());

            Console.Write("Nhap chieu cao h = ");
            double h = double.Parse(Console.ReadLine());

            double dienTichXQ = 2 * PI * r * h;
            double theTich = PI * r * r * h;

            Console.WriteLine("Dien tich xung quanh = " + dienTichXQ);
            Console.WriteLine("The tich hinh tru = " + theTich);

            Console.ReadLine();
        }
    }
}