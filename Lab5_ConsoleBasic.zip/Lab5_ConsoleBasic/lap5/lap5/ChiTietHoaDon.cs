﻿using Lap5;

namespace Lap5
{
    public class ChiTietHoaDon
    {
        public HangHoa HangHoa { get; set; }
        public int SoLuong { get; set; }

        public ChiTietHoaDon(HangHoa hangHoa, int soLuong)
        {
            HangHoa = hangHoa;
            SoLuong = soLuong > 0 ? soLuong : 1;
        }

        public double ThanhTien()
        {
            return HangHoa.DonGia * SoLuong;
        }

        public override string ToString()
        {
            return $"{HangHoa.MaHang,-10} | {HangHoa.TenHang,-25} | " +
                   $"{HangHoa.DonGia,12:N0} | {SoLuong,8} | {ThanhTien(),12:N0}";
        }
    }
}