﻿using System;

namespace Lap5
{
    public class SoNguyen
    {
        public int GiaTri { get; set; }

        public SoNguyen()
        {
            GiaTri = 0;
        }

        public SoNguyen(int giaTri)
        {
            GiaTri = giaTri;
        }

        public static SoNguyen operator +(SoNguyen a, SoNguyen b)
        {
            return new SoNguyen(a.GiaTri + b.GiaTri);
        }

        public static SoNguyen operator -(SoNguyen a, SoNguyen b)
        {
            return new SoNguyen(a.GiaTri - b.GiaTri);
        }

        public static SoNguyen operator *(SoNguyen a, SoNguyen b)
        {
            return new SoNguyen(a.GiaTri * b.GiaTri);
        }

        public static SoNguyen operator /(SoNguyen a, SoNguyen b)
        {
            if (b.GiaTri == 0)
                throw new DivideByZeroException();

            return new SoNguyen(a.GiaTri / b.GiaTri);
        }

        public bool LaChan()
        {
            return GiaTri % 2 == 0;
        }

        public bool LaLe()
        {
            return GiaTri % 2 != 0;
        }

        public bool LaNguyenTo()
        {
            if (GiaTri < 2) return false;

            for (int i = 2; i <= Math.Sqrt(GiaTri); i++)
            {
                if (GiaTri % i == 0)
                    return false;
            }

            return true;
        }

        public override string ToString()
        {
            return GiaTri.ToString();
        }
    }
}