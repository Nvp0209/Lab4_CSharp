﻿using Lap5;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Lap5
{
    public class HoaDon
    {
        public string MaHoaDon { get; set; }
        public KhachHang KhachHang { get; set; }
        public List<ChiTietHoaDon> DanhSachHangHoa { get; set; }

        public HoaDon(string maHoaDon, KhachHang khachHang)
        {
            MaHoaDon = maHoaDon;
            KhachHang = khachHang;
            DanhSachHangHoa = new List<ChiTietHoaDon>();
        }

        public void ThemHang(HangHoa hangHoa, int soLuong)
        {
            DanhSachHangHoa.Add(new ChiTietHoaDon(hangHoa, soLuong));
        }

        public bool XoaHang(string maHang)
        {
            ChiTietHoaDon item =
                DanhSachHangHoa.FirstOrDefault(
                    x => x.HangHoa.MaHang.Equals(
                        maHang,
                        StringComparison.OrdinalIgnoreCase));

            if (item == null)
                return false;

            DanhSachHangHoa.Remove(item);
            return true;
        }

        public double TongTien()
        {
            return DanhSachHangHoa.Sum(x => x.ThanhTien());
        }

        public void InHoaDon()
        {
            Console.WriteLine("HÓA ĐƠN BÁN HÀNG");
            Console.WriteLine($"Mã hóa đơn: {MaHoaDon}");
            Console.WriteLine($"Khách hàng: {KhachHang}");

            Console.WriteLine(new string('-', 85));

            foreach (ChiTietHoaDon item in DanhSachHangHoa)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine(new string('-', 85));
            Console.WriteLine($"Tổng tiền: {TongTien():N0} VNĐ");
        }
    }
}