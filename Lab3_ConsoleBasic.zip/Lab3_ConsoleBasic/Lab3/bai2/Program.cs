﻿using System;

namespace Lab3
{
    class TamGiac
    {
        public double A { get; set; }
        public double B { get; set; }
        public double C { get; set; }

        public TamGiac()
        {
            A = B = C = 0;
        }

        public TamGiac(double a, double b, double c)
        {
            A = a;
            B = b;
            C = c;
        }

        public bool KiemTraTamGiac()
        {
            return A > 0 && B > 0 && C > 0 &&
                   A + B > C &&
                   A + C > B &&
                   B + C > A;
        }

        public double TinhChuVi()
        {
            return A + B + C;
        }

        public double TinhDienTich()
        {
            double p = TinhChuVi() / 2;
            return Math.Sqrt(p * (p - A) * (p - B) * (p - C));
        }

        public string LoaiTamGiac()
        {
            if (!KiemTraTamGiac())
                return "Khong phai tam giac";

            if (A == B && B == C)
                return "Tam giac deu";

            if (A == B || A == C || B == C)
                return "Tam giac can";

            if (A * A + B * B == C * C ||
                A * A + C * C == B * B ||
                B * B + C * C == A * A)
                return "Tam giac vuong";

            return "Tam giac thuong";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap canh a: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Nhap canh b: ");
            double b = double.Parse(Console.ReadLine());

            Console.Write("Nhap canh c: ");
            double c = double.Parse(Console.ReadLine());

            TamGiac tg = new TamGiac(a, b, c);

            if (tg.KiemTraTamGiac())
            {
                Console.WriteLine("Day la tam giac hop le.");
                Console.WriteLine("Loai tam giac: " + tg.LoaiTamGiac());
                Console.WriteLine("Chu vi: " + tg.TinhChuVi());
                Console.WriteLine("Dien tich: " + tg.TinhDienTich());
            }
            else
            {
                Console.WriteLine("Ba canh khong tao thanh tam giac.");
            }

            Console.ReadKey();
        }
    }
}