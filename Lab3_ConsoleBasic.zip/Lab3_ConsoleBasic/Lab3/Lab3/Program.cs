﻿using System;

namespace Lab3
{
    class So
    {
        public double GiaTri { get; set; }

        public So()
        {
            GiaTri = 0;
        }

        public So(double giaTri)
        {
            GiaTri = giaTri;
        }

        public double Cong(So b)
        {
            return GiaTri + b.GiaTri;
        }

        public double Tru(So b)
        {
            return GiaTri - b.GiaTri;
        }

        public double Nhan(So b)
        {
            return GiaTri * b.GiaTri;
        }

        public double Chia(So b)
        {
            if (b.GiaTri == 0)
                throw new DivideByZeroException("Khong the chia cho 0.");

            return GiaTri / b.GiaTri;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap so thu nhat: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Nhap so thu hai: ");
            double b = double.Parse(Console.ReadLine());

            So so1 = new So(a);
            So so2 = new So(b);

            Console.WriteLine("Tong: " + so1.Cong(so2));
            Console.WriteLine("Hieu: " + so1.Tru(so2));
            Console.WriteLine("Tich: " + so1.Nhan(so2));

            try
            {
                Console.WriteLine("Thuong: " + so1.Chia(so2));
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Loi: " + ex.Message);
            }

            Console.ReadKey();
        }
    }
}